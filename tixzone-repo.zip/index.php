<?php
// APLIKASI BOOKING TIKET EMTE HIGHLAND RESORT - entry point
require_once __DIR__ . '/includes/auth.php';

if (current_user()) {
    header('Location: /customer/home.php');
} else {
    header('Location: /login.php');
}
exit;
