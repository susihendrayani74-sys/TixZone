<?php
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/auth.php';
require_role('petugas');

$user = current_user();
$booking = null;
$message = null;

// SCAN QR CODE / KODE TIKET -> VALIDASI BOOKING
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['cari'])) {
    $kode_booking = trim($_POST['kode_booking'] ?? '');
    $stmt = $pdo->prepare('SELECT * FROM booking WHERE kode_booking = ?');
    $stmt->execute([$kode_booking]);
    $booking = $stmt->fetch();

    if (!$booking) {
        $message = 'Kode booking tidak ditemukan.';
    } elseif ($booking['status'] !== 'dibayar') {
        $message = 'Booking belum dibayar / sudah digunakan.';
    }
}

// CATAT CHECK-IN PENGUNJUNG
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['checkin'])) {
    $booking_id = (int) $_POST['booking_id'];

    $pdo->prepare('INSERT INTO checkin_log (booking_id, petugas_id) VALUES (?, ?)')
        ->execute([$booking_id, $user['id']]);
    $pdo->prepare("UPDATE booking SET status = 'selesai' WHERE id = ?")->execute([$booking_id]);

    $message = 'Check-in berhasil dicatat.';
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Validasi Booking - TixZone Petugas</title>
    <link rel="stylesheet" href="/assets/css/style.css">
</head>
<body>
<div class="navbar">
    <strong>TixZone Petugas</strong>
    <div>
        <a href="/petugas/dashboard.php">Dashboard</a>
        <a href="/petugas/validasi_booking.php">Scan / Validasi Booking</a>
        <a href="/logout.php">Logout</a>
    </div>
</div>
<div class="container">
    <div class="card">
        <h2>Scan / Input Kode Tiket</h2>
        <!-- Untuk scan QR sungguhan, integrasikan library JS seperti html5-qrcode
             lalu isi otomatis field kode_booking di bawah ini -->
        <form method="post">
            <label>Kode Booking</label>
            <input type="text" name="kode_booking" placeholder="TXZ-XXXXXXXX" required>
            <button class="btn" style="margin-top:16px;" type="submit" name="cari" value="1">Validasi</button>
        </form>
    </div>

    <?php if ($message): ?><p class="error"><?= htmlspecialchars($message) ?></p><?php endif; ?>

    <?php if ($booking && $booking['status'] === 'dibayar'): ?>
        <div class="card">
            <h3>Data Booking Valid</h3>
            <table>
                <tr><th>Kode</th><td><?= htmlspecialchars($booking['kode_booking']) ?></td></tr>
                <tr><th>Tanggal Kunjungan</th><td><?= htmlspecialchars($booking['tanggal_kunjungan']) ?></td></tr>
                <tr><th>Jumlah Tiket</th><td><?= $booking['jumlah_tiket'] ?></td></tr>
            </table>
            <form method="post" style="margin-top:12px;">
                <input type="hidden" name="booking_id" value="<?= $booking['id'] ?>">
                <button class="btn" type="submit" name="checkin" value="1">Catat Check-in</button>
            </form>
        </div>
    <?php endif; ?>
</div>
</body>
</html>
