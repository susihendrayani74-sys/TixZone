<?php
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/auth.php';
require_role('petugas');

$checkin_hari_ini = $pdo->query("SELECT COUNT(*) FROM checkin_log WHERE DATE(waktu_checkin) = CURDATE()")->fetchColumn();
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Dashboard Petugas - TixZone</title>
    <link rel="stylesheet" href="/assets/css/style.css">
</head>
<body>
<div class="navbar">
    <strong>TixZone Petugas</strong>
    <div>
        <a href="/petugas/dashboard.php">Dashboard</a>
        <a href="/petugas/validasi_booking.php">Scan / Validasi Booking</a>
        <a href="/logout.php">Logout</a>
    </div>
</div>
<div class="container">
    <div class="card">
        <h3>Check-in Hari Ini</h3>
        <p style="font-size:28px;"><?= $checkin_hari_ini ?></p>
    </div>
</div>
</body>
</html>
