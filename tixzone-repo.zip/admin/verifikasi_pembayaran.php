<?php
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/auth.php';
require_role('admin');

$user = current_user();

// VERIFIKASI PEMBAYARAN -> update status booking jadi 'dibayar'/selesai
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $pembayaran_id = (int) $_POST['pembayaran_id'];
    $aksi = $_POST['aksi']; // terima / tolak

    $status = $aksi === 'terima' ? 'terverifikasi' : 'ditolak';
    $pdo->prepare('UPDATE pembayaran SET status = ?, verifikasi_oleh = ? WHERE id = ?')
        ->execute([$status, $user['id'], $pembayaran_id]);

    if ($aksi === 'terima') {
        $stmt = $pdo->prepare('SELECT booking_id FROM pembayaran WHERE id = ?');
        $stmt->execute([$pembayaran_id]);
        $booking_id = $stmt->fetchColumn();
        $pdo->prepare("UPDATE booking SET status = 'dibayar' WHERE id = ?")->execute([$booking_id]);
    }

    header('Location: /admin/verifikasi_pembayaran.php');
    exit;
}

$pembayaran_list = $pdo->query("SELECT p.*, b.kode_booking, b.total_harga, u.nama
                                 FROM pembayaran p
                                 JOIN booking b ON b.id = p.booking_id
                                 JOIN users u ON u.id = b.user_id
                                 WHERE p.status = 'pending'
                                 ORDER BY p.created_at ASC")->fetchAll();
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Verifikasi Pembayaran - TixZone Admin</title>
    <link rel="stylesheet" href="/assets/css/style.css">
</head>
<body>
<div class="navbar">
    <strong>TixZone Admin</strong>
    <div>
        <a href="/admin/dashboard.php">Dashboard</a>
        <a href="/admin/destinasi.php">Kelola Destinasi</a>
        <a href="/admin/verifikasi_pembayaran.php">Verifikasi Pembayaran</a>
        <a href="/logout.php">Logout</a>
    </div>
</div>
<div class="container">
    <div class="card">
        <h2>Pembayaran Menunggu Verifikasi</h2>
        <table>
            <tr><th>Kode Booking</th><th>Customer</th><th>Total</th><th>Bukti</th><th>Aksi</th></tr>
            <?php foreach ($pembayaran_list as $p): ?>
                <tr>
                    <td><?= htmlspecialchars($p['kode_booking']) ?></td>
                    <td><?= htmlspecialchars($p['nama']) ?></td>
                    <td>Rp<?= number_format($p['total_harga'], 0, ',', '.') ?></td>
                    <td><?php if ($p['bukti_bayar']): ?><a href="/uploads/bukti_bayar/<?= htmlspecialchars($p['bukti_bayar']) ?>" target="_blank">Lihat</a><?php endif; ?></td>
                    <td>
                        <form method="post" style="display:inline;">
                            <input type="hidden" name="pembayaran_id" value="<?= $p['id'] ?>">
                            <button class="btn" type="submit" name="aksi" value="terima">Terima</button>
                            <button class="btn btn-secondary" type="submit" name="aksi" value="tolak">Tolak</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; ?>
            <?php if (empty($pembayaran_list)): ?>
                <tr><td colspan="5">Tidak ada pembayaran pending.</td></tr>
            <?php endif; ?>
        </table>
    </div>
</div>
</body>
</html>
