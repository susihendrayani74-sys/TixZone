<?php
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/auth.php';
require_role('admin');

$destinasi_id = (int) ($_GET['destinasi_id'] ?? 0);

// ATUR HARGA / KUOTA TIKET -> SIMPAN DATA
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['tambah'])) {
    $jenis = trim($_POST['jenis_tiket'] ?? '');
    $harga = (float) ($_POST['harga'] ?? 0);
    $kuota = (int) ($_POST['kuota_harian'] ?? 0);

    if ($jenis !== '' && $harga > 0) {
        $pdo->prepare('INSERT INTO tiket (destinasi_id, jenis_tiket, harga, kuota_harian) VALUES (?, ?, ?, ?)')
            ->execute([$destinasi_id, $jenis, $harga, $kuota]);
    }
    header("Location: /admin/tiket_harga.php?destinasi_id={$destinasi_id}");
    exit;
}

$stmt = $pdo->prepare('SELECT * FROM tiket WHERE destinasi_id = ?');
$stmt->execute([$destinasi_id]);
$tiket_list = $stmt->fetchAll();

$stmt = $pdo->prepare('SELECT nama_destinasi FROM destinasi WHERE id = ?');
$stmt->execute([$destinasi_id]);
$nama_destinasi = $stmt->fetchColumn();
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Kelola Tiket & Harga - TixZone Admin</title>
    <link rel="stylesheet" href="/assets/css/style.css">
</head>
<body>
<div class="navbar">
    <strong>TixZone Admin</strong>
    <div>
        <a href="/admin/dashboard.php">Dashboard</a>
        <a href="/admin/destinasi.php">Kelola Destinasi</a>
        <a href="/admin/verifikasi_pembayaran.php">Verifikasi Pembayaran</a>
        <a href="/logout.php">Logout</a>
    </div>
</div>
<div class="container">
    <div class="card">
        <h2>Tiket & Harga - <?= htmlspecialchars($nama_destinasi ?: 'Destinasi') ?></h2>
        <form method="post">
            <label>Jenis Tiket</label>
            <input type="text" name="jenis_tiket" placeholder="Reguler / VIP / Weekday" required>
            <label>Harga (Rp)</label>
            <input type="number" name="harga" min="0" required>
            <label>Kuota Harian</label>
            <input type="number" name="kuota_harian" min="0" required>
            <button class="btn" style="margin-top:16px;" type="submit" name="tambah" value="1">Simpan</button>
        </form>
    </div>
    <div class="card">
        <h2>Daftar Tiket</h2>
        <table>
            <tr><th>Jenis</th><th>Harga</th><th>Kuota Harian</th></tr>
            <?php foreach ($tiket_list as $t): ?>
                <tr>
                    <td><?= htmlspecialchars($t['jenis_tiket']) ?></td>
                    <td>Rp<?= number_format($t['harga'], 0, ',', '.') ?></td>
                    <td><?= $t['kuota_harian'] ?></td>
                </tr>
            <?php endforeach; ?>
        </table>
    </div>
</div>
</body>
</html>
