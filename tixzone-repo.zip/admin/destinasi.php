<?php
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/auth.php';
require_role('admin');

// SIMPAN DATA -> VALIDASI DATA -> DATABASE
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['tambah'])) {
    $nama = trim($_POST['nama_destinasi'] ?? '');
    $deskripsi = trim($_POST['deskripsi'] ?? '');
    $lokasi = trim($_POST['lokasi'] ?? '');

    if ($nama !== '') { // VALIDASI DATA
        $pdo->prepare('INSERT INTO destinasi (nama_destinasi, deskripsi, lokasi) VALUES (?, ?, ?)')
            ->execute([$nama, $deskripsi, $lokasi]);
    }
    header('Location: /admin/destinasi.php');
    exit;
}

// EDIT / HAPUS DESTINASI
if (isset($_GET['hapus'])) {
    $pdo->prepare('DELETE FROM destinasi WHERE id = ?')->execute([(int) $_GET['hapus']]);
    header('Location: /admin/destinasi.php');
    exit;
}

$destinasi = $pdo->query('SELECT * FROM destinasi ORDER BY id DESC')->fetchAll();
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Kelola Destinasi - TixZone Admin</title>
    <link rel="stylesheet" href="/assets/css/style.css">
</head>
<body>
<div class="navbar">
    <strong>TixZone Admin</strong>
    <div>
        <a href="/admin/dashboard.php">Dashboard</a>
        <a href="/admin/destinasi.php">Kelola Destinasi</a>
        <a href="/admin/tiket_harga.php">Tiket & Harga</a>
        <a href="/admin/verifikasi_pembayaran.php">Verifikasi Pembayaran</a>
        <a href="/logout.php">Logout</a>
    </div>
</div>
<div class="container">
    <div class="card">
        <h2>Tambah Destinasi</h2>
        <form method="post">
            <label>Nama Destinasi</label>
            <input type="text" name="nama_destinasi" required>
            <label>Deskripsi</label>
            <textarea name="deskripsi" rows="2"></textarea>
            <label>Lokasi</label>
            <input type="text" name="lokasi">
            <button class="btn" style="margin-top:16px;" type="submit" name="tambah" value="1">Simpan</button>
        </form>
    </div>
    <div class="card">
        <h2>Daftar Destinasi</h2>
        <table>
            <tr><th>Nama</th><th>Lokasi</th><th>Status</th><th>Aksi</th></tr>
            <?php foreach ($destinasi as $d): ?>
                <tr>
                    <td><?= htmlspecialchars($d['nama_destinasi']) ?></td>
                    <td><?= htmlspecialchars($d['lokasi']) ?></td>
                    <td><?= htmlspecialchars($d['status']) ?></td>
                    <td>
                        <a href="/admin/tiket_harga.php?destinasi_id=<?= $d['id'] ?>">Kelola Tiket</a> |
                        <a href="/admin/destinasi.php?hapus=<?= $d['id'] ?>" onclick="return confirm('Hapus destinasi ini?')">Hapus</a>
                    </td>
                </tr>
            <?php endforeach; ?>
        </table>
    </div>
</div>
</body>
</html>
