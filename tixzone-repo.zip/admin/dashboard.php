<?php
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/auth.php';
require_role('admin');

$total_destinasi = $pdo->query('SELECT COUNT(*) FROM destinasi')->fetchColumn();
$total_booking = $pdo->query('SELECT COUNT(*) FROM booking')->fetchColumn();
$pembayaran_pending = $pdo->query("SELECT COUNT(*) FROM pembayaran WHERE status = 'pending'")->fetchColumn();
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Dashboard Admin - TixZone</title>
    <link rel="stylesheet" href="/assets/css/style.css">
</head>
<body>
<div class="navbar">
    <strong>TixZone Admin</strong>
    <div>
        <a href="/admin/dashboard.php">Dashboard</a>
        <a href="/admin/destinasi.php">Kelola Destinasi</a>
        <a href="/admin/tiket_harga.php">Tiket & Harga</a>
        <a href="/admin/verifikasi_pembayaran.php">Verifikasi Pembayaran</a>
        <a href="/logout.php">Logout</a>
    </div>
</div>
<div class="container">
    <div class="grid-3">
        <div class="card"><h3>Total Destinasi</h3><p style="font-size:28px;"><?= $total_destinasi ?></p></div>
        <div class="card"><h3>Total Booking</h3><p style="font-size:28px;"><?= $total_booking ?></p></div>
        <div class="card"><h3>Pembayaran Pending</h3><p style="font-size:28px;"><?= $pembayaran_pending ?></p></div>
    </div>
</div>
</body>
</html>
