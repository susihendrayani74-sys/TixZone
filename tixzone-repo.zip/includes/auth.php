<?php
session_start();

/**
 * Pastikan hanya role tertentu yang bisa mengakses halaman.
 * Sesuai flowchart: role terdiri dari admin, petugas, customer.
 */
function require_role(string $role): void
{
    if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== $role) {
        header('Location: /login.php?error=unauthorized');
        exit;
    }
}

function current_user(): ?array
{
    return $_SESSION['user'] ?? null;
}

function logout(): void
{
    session_unset();
    session_destroy();
    header('Location: /login.php');
    exit;
}
