<?php
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/auth.php';
require_role('customer');

$user = current_user();
$tiket_id = (int) ($_GET['tiket_id'] ?? $_POST['tiket_id'] ?? 0);
$tanggal_kunjungan = $_GET['tanggal_kunjungan'] ?? $_POST['tanggal_kunjungan'] ?? '';
$jumlah_tiket = (int) ($_GET['jumlah_tiket'] ?? $_POST['jumlah_tiket'] ?? 1);

$stmt = $pdo->prepare('SELECT * FROM tiket WHERE id = ?');
$stmt->execute([$tiket_id]);
$tiket = $stmt->fetch();

if (!$tiket) {
    die('Tiket tidak ditemukan');
}

$total_harga = $tiket['harga'] * $jumlah_tiket;

// KONFIRMASI BOOKING -> simpan ke tabel booking, status menunggu_pembayaran
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['konfirmasi'])) {
    $kode_booking = 'TXZ-' . strtoupper(uniqid());

    $stmt = $pdo->prepare('INSERT INTO booking (kode_booking, user_id, tiket_id, tanggal_kunjungan, jumlah_tiket, total_harga)
                            VALUES (?, ?, ?, ?, ?, ?)');
    $stmt->execute([$kode_booking, $user['id'], $tiket_id, $tanggal_kunjungan, $jumlah_tiket, $total_harga]);

    $booking_id = $pdo->lastInsertId();
    header("Location: /customer/pembayaran.php?booking_id={$booking_id}");
    exit;
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Konfirmasi Booking - TixZone</title>
    <link rel="stylesheet" href="/assets/css/style.css">
</head>
<body>
<div class="container">
    <div class="card">
        <h2>Konfirmasi Booking</h2>
        <table>
            <tr><th>Jenis Tiket</th><td><?= htmlspecialchars($tiket['jenis_tiket']) ?></td></tr>
            <tr><th>Tanggal Kunjungan</th><td><?= htmlspecialchars($tanggal_kunjungan) ?></td></tr>
            <tr><th>Jumlah Tiket</th><td><?= $jumlah_tiket ?></td></tr>
            <tr><th>Total Harga</th><td>Rp<?= number_format($total_harga, 0, ',', '.') ?></td></tr>
        </table>
        <form method="post" style="margin-top:16px;">
            <input type="hidden" name="tiket_id" value="<?= $tiket_id ?>">
            <input type="hidden" name="tanggal_kunjungan" value="<?= htmlspecialchars($tanggal_kunjungan) ?>">
            <input type="hidden" name="jumlah_tiket" value="<?= $jumlah_tiket ?>">
            <label>Nama Pemesan</label>
            <input type="text" name="nama_pemesan" value="<?= htmlspecialchars($user['nama']) ?>" required>
            <button class="btn" style="margin-top:16px;" type="submit" name="konfirmasi" value="1">Konfirmasi Booking</button>
        </form>
    </div>
</div>
</body>
</html>
