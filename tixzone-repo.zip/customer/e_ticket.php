<?php
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/auth.php';
require_role('customer');

$booking_id = (int) ($_GET['booking_id'] ?? 0);
$stmt = $pdo->prepare('SELECT b.*, t.jenis_tiket, d.nama_destinasi
                        FROM booking b
                        JOIN tiket t ON t.id = b.tiket_id
                        JOIN destinasi d ON d.id = t.destinasi_id
                        WHERE b.id = ?');
$stmt->execute([$booking_id]);
$booking = $stmt->fetch();

if (!$booking) {
    die('Booking tidak ditemukan');
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>E-Ticket - TixZone</title>
    <link rel="stylesheet" href="/assets/css/style.css">
</head>
<body>
<div class="container" style="max-width:480px;">
    <div class="card" style="text-align:center;">
        <h2>🎟️ E-Ticket TixZone</h2>
        <p><?= htmlspecialchars($booking['nama_destinasi']) ?></p>
        <hr style="margin:12px 0;">
        <p>Kode Booking</p>
        <h1 style="letter-spacing:2px;"><?= htmlspecialchars($booking['kode_booking']) ?></h1>
        <!-- TODO: render QR code asli dari kode_booking, misalnya pakai library endroid/qr-code (composer) -->
        <p style="margin-top:12px;">Tunjukkan kode ini ke petugas tiket saat check-in.</p>
        <table style="margin-top:16px;">
            <tr><th>Jenis Tiket</th><td><?= htmlspecialchars($booking['jenis_tiket']) ?></td></tr>
            <tr><th>Tanggal</th><td><?= htmlspecialchars($booking['tanggal_kunjungan']) ?></td></tr>
            <tr><th>Jumlah</th><td><?= $booking['jumlah_tiket'] ?></td></tr>
            <tr><th>Status</th><td><?= htmlspecialchars($booking['status']) ?></td></tr>
        </table>
        <a class="btn" style="margin-top:16px;" href="/customer/home.php">Kembali ke Beranda</a>
    </div>
</div>
</body>
</html>
