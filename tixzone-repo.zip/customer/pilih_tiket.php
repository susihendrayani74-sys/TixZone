<?php
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/auth.php';
require_role('customer');

$destinasi_id = (int) ($_GET['destinasi_id'] ?? 0);
$stmt = $pdo->prepare('SELECT * FROM tiket WHERE destinasi_id = ?');
$stmt->execute([$destinasi_id]);
$tiket_list = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Pilih Tiket - TixZone</title>
    <link rel="stylesheet" href="/assets/css/style.css">
</head>
<body>
<div class="container">
    <div class="card">
        <h2>Pilih Jenis Tiket</h2>
        <form method="get" action="/customer/isi_data_pemesan.php">
            <label>Jenis Tiket</label>
            <select name="tiket_id" required>
                <?php foreach ($tiket_list as $t): ?>
                    <option value="<?= $t['id'] ?>">
                        <?= htmlspecialchars($t['jenis_tiket']) ?> - Rp<?= number_format($t['harga'], 0, ',', '.') ?>
                    </option>
                <?php endforeach; ?>
            </select>

            <label>Tanggal Kunjungan</label>
            <input type="date" name="tanggal_kunjungan" required min="<?= date('Y-m-d') ?>">

            <label>Jumlah Tiket</label>
            <input type="number" name="jumlah_tiket" min="1" value="1" required>

            <button class="btn" style="margin-top:16px;" type="submit">Lanjut</button>
        </form>
    </div>
</div>
</body>
</html>
