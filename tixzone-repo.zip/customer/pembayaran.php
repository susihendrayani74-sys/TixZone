<?php
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/auth.php';
require_role('customer');

$booking_id = (int) ($_GET['booking_id'] ?? 0);
$stmt = $pdo->prepare('SELECT * FROM booking WHERE id = ?');
$stmt->execute([$booking_id]);
$booking = $stmt->fetch();

if (!$booking) {
    die('Booking tidak ditemukan');
}

// PEMBAYARAN: upload bukti bayar, status booking -> dibayar (menunggu verifikasi admin)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $metode = $_POST['metode_pembayaran'] ?? 'transfer';
    $bukti_bayar = null;

    if (!empty($_FILES['bukti_bayar']['name'])) {
        $ext = pathinfo($_FILES['bukti_bayar']['name'], PATHINFO_EXTENSION);
        $bukti_bayar = 'bukti_' . $booking_id . '.' . $ext;
        move_uploaded_file($_FILES['bukti_bayar']['tmp_name'], __DIR__ . '/../uploads/bukti_bayar/' . $bukti_bayar);
    }

    $pdo->prepare('INSERT INTO pembayaran (booking_id, metode_pembayaran, bukti_bayar) VALUES (?, ?, ?)')
        ->execute([$booking_id, $metode, $bukti_bayar]);

    $pdo->prepare("UPDATE booking SET status = 'dibayar' WHERE id = ?")->execute([$booking_id]);

    header("Location: /customer/e_ticket.php?booking_id={$booking_id}");
    exit;
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Pembayaran - TixZone</title>
    <link rel="stylesheet" href="/assets/css/style.css">
</head>
<body>
<div class="container">
    <div class="card">
        <h2>Pembayaran</h2>
        <p>Kode Booking: <strong><?= htmlspecialchars($booking['kode_booking']) ?></strong></p>
        <p>Total: Rp<?= number_format($booking['total_harga'], 0, ',', '.') ?></p>
        <form method="post" enctype="multipart/form-data">
            <label>Metode Pembayaran</label>
            <select name="metode_pembayaran">
                <option value="transfer_bank">Transfer Bank</option>
                <option value="e_wallet">E-Wallet</option>
            </select>
            <label>Upload Bukti Pembayaran</label>
            <input type="file" name="bukti_bayar" accept="image/*" required>
            <button class="btn" style="margin-top:16px;" type="submit">Kirim Bukti Pembayaran</button>
        </form>
    </div>
</div>
</body>
</html>
