<?php
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/auth.php';
require_role('customer');

// LIHAT INFORMASI DESTINASI
$destinasi = $pdo->query("SELECT * FROM destinasi WHERE status = 'aktif'")->fetchAll();
$user = current_user();
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Halaman Utama - TixZone</title>
    <link rel="stylesheet" href="/assets/css/style.css">
</head>
<body>
<div class="navbar">
    <strong>TixZone</strong>
    <div>
        Halo, <?= htmlspecialchars($user['nama']) ?>
        <a href="/logout.php">Logout</a>
    </div>
</div>
<div class="container">
    <h2>Destinasi Emte Highland Resort</h2>
    <div class="grid-3">
        <?php foreach ($destinasi as $d): ?>
            <div class="card">
                <h3><?= htmlspecialchars($d['nama_destinasi']) ?></h3>
                <p><?= htmlspecialchars($d['deskripsi']) ?></p>
                <a class="btn" href="/customer/pilih_tiket.php?destinasi_id=<?= $d['id'] ?>">Pilih Tiket</a>
            </div>
        <?php endforeach; ?>
        <?php if (empty($destinasi)): ?>
            <p>Belum ada destinasi tersedia.</p>
        <?php endif; ?>
    </div>
</div>
</body>
</html>
