<?php
require_once __DIR__ . '/../includes/db.php';

$error = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nama = trim($_POST['nama'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';

    if ($nama && $email && $password) {
        $hash = password_hash($password, PASSWORD_DEFAULT);
        try {
            $stmt = $pdo->prepare('INSERT INTO users (nama, email, password, role) VALUES (?, ?, ?, "customer")');
            $stmt->execute([$nama, $email, $hash]);
            header('Location: /login.php');
            exit;
        } catch (PDOException $e) {
            $error = 'Email sudah terdaftar';
        }
    } else {
        $error = 'Semua field wajib diisi';
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Registrasi - TixZone</title>
    <link rel="stylesheet" href="/assets/css/style.css">
</head>
<body>
<div class="container" style="max-width:420px;">
    <div class="card">
        <h2>Registrasi Customer</h2>
        <?php if ($error): ?><p class="error"><?= htmlspecialchars($error) ?></p><?php endif; ?>
        <form method="post">
            <label>Nama</label>
            <input type="text" name="nama" required>
            <label>Email</label>
            <input type="email" name="email" required>
            <label>Password</label>
            <input type="password" name="password" required>
            <button class="btn" style="margin-top:16px;" type="submit">Daftar</button>
        </form>
        <p style="margin-top:12px;">Sudah punya akun? <a href="/login.php">Login</a></p>
    </div>
</div>
</body>
</html>
