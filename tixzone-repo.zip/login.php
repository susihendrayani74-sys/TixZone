<?php
require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/auth.php';

$error = $_GET['error'] ?? null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';

    $stmt = $pdo->prepare('SELECT * FROM users WHERE email = ?');
    $stmt->execute([$email]);
    $user = $stmt->fetch();

    // VALIDASI LOGIN sesuai flowchart admin/petugas/customer
    if ($user && password_verify($password, $user['password'])) {
        $_SESSION['user'] = [
            'id' => $user['id'],
            'nama' => $user['nama'],
            'role' => $user['role'],
        ];
        match ($user['role']) {
            'admin' => header('Location: /admin/dashboard.php'),
            'petugas' => header('Location: /petugas/dashboard.php'),
            default => header('Location: /customer/home.php'),
        };
        exit;
    }

    $error = 'Email atau password salah'; // PESAN ERROR -> LOGIN KEMBALI
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Login - TixZone</title>
    <link rel="stylesheet" href="/assets/css/style.css">
</head>
<body>
<div class="container" style="max-width:420px;">
    <div class="card">
        <h2>Login TixZone</h2>
        <?php if ($error): ?><p class="error"><?= htmlspecialchars($error) ?></p><?php endif; ?>
        <form method="post">
            <label>Email</label>
            <input type="email" name="email" required>
            <label>Password</label>
            <input type="password" name="password" required>
            <button class="btn" style="margin-top:16px;" type="submit">Login</button>
        </form>
        <p style="margin-top:12px;">Belum punya akun? <a href="/customer/register.php">Registrasi</a></p>
    </div>
</div>
</body>
</html>
