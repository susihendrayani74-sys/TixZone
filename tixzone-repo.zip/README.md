# TixZone

Aplikasi web booking tiket untuk **Emte Highland Resort, Ciwidey**. Dibangun sebagai proyek kelompok (mata kuliah/tugas kampus).

## Tim
- Susi Hendrayani — Frontend / UI-UX
- Nayla Khoirunnisa — Backend / Database

## Role Sistem
Sesuai flowchart utama sistem, aplikasi memiliki 3 peran:

1. **Customer** — registrasi/login, lihat destinasi, pilih jenis tiket, pilih tanggal & jumlah tiket, isi data pemesan, konfirmasi booking, pembayaran, dapat e-ticket.
2. **Admin** — login, kelola destinasi, kelola tiket & harga, kelola kuota, verifikasi pembayaran.
3. **Petugas Tiket** — login, scan QR code / kode tiket, validasi booking, catat check-in pengunjung.

## Tech Stack
- PHP native (PDO) + MySQL — dipilih karena ringan, mudah dijalankan di XAMPP/Laragon tanpa build tool, dan umum dipakai untuk proyek tugas kampus.
- HTML/CSS vanilla untuk tampilan (lihat `assets/css/style.css`).

> Stack ini rekomendasi awal — struktur modular sehingga tetap mudah dipindah ke Laravel atau framework lain kalau dibutuhkan nanti.

## Struktur Folder
```
tixzone/
├── admin/              # Halaman & logika untuk admin
├── customer/           # Halaman & logika untuk customer
├── petugas/             # Halaman & logika untuk petugas tiket
├── includes/           # db.php (koneksi PDO), auth.php (session & role guard)
├── assets/css/         # Stylesheet
├── database/           # tixzone.sql — skema database
├── uploads/bukti_bayar/ # Upload bukti pembayaran customer
├── index.php           # Entry point, redirect sesuai status login
├── login.php           # Login untuk ketiga role
└── logout.php
```

## Cara Menjalankan (Lokal)
1. Install XAMPP / Laragon (PHP 8+, MySQL).
2. Clone/salin folder ini ke `htdocs` (XAMPP) atau `www` (Laragon).
3. Buat database dengan menjalankan `database/tixzone.sql` di phpMyAdmin.
4. Sesuaikan kredensial di `includes/db.php` jika perlu.
5. Akses `http://localhost/tixzone/` di browser.
6. Buat akun customer lewat halaman **Registrasi**, atau update password hash akun admin/petugas contoh di tabel `users` (gunakan `password_hash()` PHP).

## Status Pengembangan
Proyek ini masih berupa kerangka awal (scaffold) mengikuti flowchart dan analisis kebutuhan:
- [x] Alur customer: registrasi → pilih destinasi → pilih tiket → booking → pembayaran → e-ticket
- [x] Alur admin: kelola destinasi, tiket & harga, verifikasi pembayaran
- [x] Alur petugas: validasi booking & catat check-in
- [ ] Validasi kuota harian saat booking (tabel `kuota_harian` sudah ada, logika pengecekan belum diimplementasi)
- [ ] Generate QR code asli untuk e-ticket (rencana pakai library `endroid/qr-code` via Composer)
- [ ] Autentikasi & hashing password untuk akun admin/petugas contoh
- [ ] Validasi input & keamanan lebih lengkap (CSRF, sanitasi upload file)

## Dokumen Pendukung
Flowchart sistem (utama, admin, customer, petugas) dan dokumen analisis kebutuhan, product backlog, sprint plan, RACI matrix, serta risk register dikelola terpisah di dokumen proposal proyek.
